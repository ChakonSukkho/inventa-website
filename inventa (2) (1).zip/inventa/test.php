<?php
echo "PHP OK";
?>